//Faça um app que tenha um inputText, onde o usuário deve digitar
//uma frase.
//Use um componente Text juntamente com uma hook useState
//para apresentar a quantidade de caracteres do texto enquanto o
//usuário está digitando.

import * as React from 'react';
import { Text, View, StyleSheet, TextInput } from 'react-native';

export default function App() {

const [frase, setFrase] = React.useState("");

  return (
    <View>
      <TextInput style ={style.input} 
      onChangeText = {setFrase}/>
      <Text>Frase digitada: {frase} | Num de caracteres: {frase.length}</Text>
    </View>
  );
}

const style = StyleSheet.create({
  input:{
    borderWidth:1
  }
})